# -*- coding: utf-8 -*-
"""
Created on Tue Oct 24 16:52:51 2023

@author: sssuh
"""
import pandas as pd
pd.options.mode.chained_assignment = None

import numpy as np


#loading subset of bio dataset with no nulls
df1= pd.read_csv ('train_data2.csv') 
df1.head(10)

#this dataset has about 12600 rows
df1.shape

#checking correlation b/w age and class year
df1.corr()

import seaborn as sns

#seeing age vs class year relation through scatter plot
sns.scatterplot(x='AGE', y='PRIMARY CLASS YEAR', data=df1)
from sklearn.preprocessing import LabelEncoder

#converting categorical variable
lb = LabelEncoder()
df1['PRIMARY ALUMNI STATUS'] = lb.fit_transform(df1['PRIMARY ALUMNI STATUS'])

#applying linear regression model
from sklearn.linear_model import LinearRegression

model=LinearRegression()

#age and alumni status as the predictors and class year as the target
X=df1[['AGE','PRIMARY ALUMNI STATUS']]
y=df1['PRIMARY CLASS YEAR']

model.fit(X,y)

#prediting sample of age = 54 and alumni status = undergraduate
#class year and alumni status as the predictors and age as the target
model.predict(np.array([[54, 2]]))


model2=LinearRegression()

y1=df1['AGE']
X1=df1[['PRIMARY CLASS YEAR', 'PRIMARY ALUMNI STATUS']]

model2.fit(X1,y1)

#********************************************************************************************************************************#
#loading bio dataset
df500= pd.read_csv ('bio data.csv') 
df500.head(10)

#checking number of rows and columns 
df500.shape

#looking for duplicates
df500.duplicated().sum()

#Drop Duplicate Observations.
df500.drop_duplicates(inplace=True)

#looking for duplicates
df500.duplicated().sum()

df500.shape

#checking for missing values
df500.isnull().sum()

#dropping Race column
df500.drop(['RACE/ETHNICITY'], axis=1, inplace=True)
df500 = df500.reset_index(drop=True)  # To reset the df_sales index
df500

#dropping Zipcode column
df500.drop(['HOME ZIPCODE'], axis=1, inplace=True)
df500 = df500.reset_index(drop=True)  # To reset the df_sales index
df500

# Replace "Unknown" for missing value 
df500['HOME COUNTRY'].fillna('Unknown', inplace=True)
df500['HOME STATE'].fillna('Unknown', inplace=True)
df500['HOME CITY'].fillna('Unknown', inplace=True)
df500['PRIMARY ACADEMIC UNIT'].fillna('Unknown', inplace=True)
df500['PRIMARY CONSTITUENT TYPE'].fillna('Unknown', inplace=True)
df500['PRIMARY CONSTITUENT TYPE'].fillna('Unknown', inplace=True)
df500['CONSTITUENT TYPE(S)'].fillna('Unknown', inplace=True)
df500['GENDER'].fillna('Unknown', inplace=True)
df500['MARITAL STATUS'].fillna('Unknown', inplace=True)
df500['PRIMARY ALUMNI STATUS'].fillna('Unknown', inplace=True)

#checking for missing values
df500.isnull().sum()

#converting categorical variable
lb = LabelEncoder()
df500['PRIMARY ALUMNI STATUS'] = lb.fit_transform(df500['PRIMARY ALUMNI STATUS'])

#checking for missing values
df500.isnull().sum()

#Formula:
#Preservation of data by applying formulas to derive missing values 
#if Age is N/A and Graduation Year isn't then check Degree Level
#if graduate then apply formula Age (for the index) = 25 + 2023 - Graduation Year (for the index)
#else if Degree Level is undergraduate Age (for the index) = 21 + 2023 - Graduation Year (for the index)

#Case: Age is null and class year is not
for index, row in df500.iterrows():
    if pd.isna(row['AGE']) and not pd.isna(row['PRIMARY CLASS YEAR']):
        if row['PRIMARY ALUMNI STATUS'] == 0:
            df500.at[index, 'AGE'] = 25 + 2023 - row['PRIMARY CLASS YEAR']
        elif row['PRIMARY ALUMNI STATUS'] == 2:
            df500.at[index, 'AGE'] = 21 + 2023 - row['PRIMARY CLASS YEAR']
          
            
#checking for missing values
df500.isnull().sum()

#Case: Class year is null and age is not            
#iterating through rows and predicting the class year based on linear regression model trained above
#with age and alumni status as the predictors and class year as the target
for index, row in df500.iterrows():
    if pd.isna(row['PRIMARY CLASS YEAR']) and not pd.isna(row['AGE']):
        df500.at[index,'PRIMARY CLASS YEAR']=model.predict(np.array([[row['AGE'], row['PRIMARY ALUMNI STATUS']]]))

#discrepancy b/w age and class year, as still some values where age is null and class year is not 
#Hence, iterating through rows and predicting the class year based on a second linear regression model trained above
#with class year and alumni status as the predictors and age as the target
for index, row in df500.iterrows():
    if pd.isna(row['AGE']) and not pd.isna(row['PRIMARY CLASS YEAR']):
        df500.at[index,'AGE']=model2.predict(np.array([[row['PRIMARY CLASS YEAR'], row['PRIMARY ALUMNI STATUS']]]))
        
#checking for missing values
df500.isnull().sum()

#as now class year and age have null values for the same rows
#there is no way of deriving any values
#Hence, we are dropping these rows
#dropping missing values
df500.dropna(axis=0, how='any', inplace=True)
df500 = df500.reset_index(drop=True)

df500.shape

#checking for missing values
df500.isnull().sum()

#defining a mapping from encoded labels to original categories
label_to_category = {0: 'Graduate', 1: 'Non-degreed', 2: 'Undergraduate', 3: 'Unknown'}

#using the mapping to convert the encoded labels back to original categories
df500['PRIMARY ALUMNI STATUS'] = df500['PRIMARY ALUMNI STATUS'].map(label_to_category)

df500.info()

df500.to_csv("bio_data_finalclean.csv", index=False)

#********************************************************************************************************************************#

#loading giving dataset
df2500= pd.read_csv ('giving data.csv') 

df2500.shape

#checking for missing values
df2500.isnull().sum()

#looking for duplicates
df2500.duplicated().sum()

#Drop Duplicate Observations.
df2500.drop_duplicates(inplace=True)

df2500.shape

#df2500.to_csv("giving_clean.csv", index=False)


#********************************************************************************************************************************#
#merging psuedocode 

#merge the two DataFrames on 'ACCOUNTID'
#merged_df = df2500.merge(df500, on='ACCOUNTID', how='inner')

#checking for missing values
#merged_df.isnull().sum()

#left join to keep all rows from the giving data and merge corresponding bio data
#left_merge = df2500.merge(df500, on='ACCOUNTID', how='left')

#right join to keep all rows from the bio data and merge corresponding giving data
#right_merge = df2500.merge(df500, on='ACCOUNTID', how='right')

#concatenate the results to get the combined dataset
#merged_df = pd.concat([left_merge, right_merge], axis=0, ignore_index=True)


#********************************************************************************************************************************#
#loading contact dataset
df4000= pd.read_csv ('contact data.csv') 

df4000.shape

#looking for duplicates
df4000.duplicated().sum()

#checking for missing values
df4000.isnull().sum()

# Replace "Unknown" for missing value 
df4000['Contact in FY23?'].fillna('Unknown', inplace=True)
df4000['Contact between FY21-FY23?'].fillna('Unknown', inplace=True)
df4000['Contact between FY19-FY23?'].fillna('Unknown', inplace=True)


df4000['Total number of contact within last 5 Fys'].fillna(0, inplace=True)

#df4000.to_csv("contact_clean.csv", index=False)

#checking for missing values
df4000.isnull().sum()

#********************************************************************************************************************************#
#loading events dataset
df6500= pd.read_csv ('events attendance data.csv') 

df6500.shape

#looking for duplicates
df6500.duplicated().sum()

#checking for missing values
df6500.isnull().sum()
    
#df6500.to_csv("events_clean.csv", index=False)

# Merge the two DataFrames on 'ACCOUNTID'
merged_df = df4000.merge(df6500, on='ACCOUNTID', how='outer')

#As events dataset has only one column, I merged it with contacts dataset which has the same number of rows
merged_df.to_csv("events_contacts_merge.csv", index=False)
